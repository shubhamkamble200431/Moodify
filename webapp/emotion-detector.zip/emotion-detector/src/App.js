import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Papa from 'papaparse';
import './App.css';

function App() {
    const [selectedFile, setSelectedFile] = useState(null);
    const [predictions, setPredictions] = useState([]);
    const [processingTime, setProcessingTime] = useState(null);
    const [imageUrl, setImageUrl] = useState(null);
    const [songs, setSongs] = useState([]);
    const [recommendedSongs, setRecommendedSongs] = useState([]);

    // Load the CSV file
    useEffect(() => {
        Papa.parse('/songs1.csv', {
            download: true,
            header: true,
            complete: (result) => {
                setSongs(result.data);
            },
            error: (error) => {
                console.error("Error loading CSV file:", error);
            }
        });
    }, []);

    const handleFileChange = (e) => {
        setSelectedFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!selectedFile) return;

        const formData = new FormData();
        formData.append('image', selectedFile);

        try {
            const response = await axios.post('http://127.0.0.1:8000/predict', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            const { processing_time, predictions, image } = response.data;
            setPredictions(predictions);
            setProcessingTime(processing_time);
            setImageUrl(`data:image/jpeg;base64,${image}`);
            
            // Randomize and set recommended songs based on prediction
            if (predictions.length > 0) {
                const mood = predictions[0];
                const filteredSongs = songs.filter(song => song.mood === mood);
                const shuffledSongs = filteredSongs.sort(() => 0.5 - Math.random()).slice(0, 5);
                setRecommendedSongs(shuffledSongs);
            }

        } catch (error) {
            console.error("Error uploading the image", error);
        }
    };

    return (
        <div className="App">
            <h1>Emotion Detection</h1>
            <form onSubmit={handleSubmit}>
                <input type="file" onChange={handleFileChange} accept="image/*" />
                <button type="submit">Submit</button>
            </form>

            {processingTime && (
                <div>
                    <h3>Processing Time: {processingTime.toFixed(4)} seconds</h3>
                </div>
            )}
            {predictions.length > 0 && (
                <div>
                    <h3>Detected Expressions:</h3>
                    <ul>
                        {predictions.map((expression, index) => (
                            <li key={index}>{expression}</li>
                        ))}
                    </ul>
                </div>
            )}
            {recommendedSongs.length > 0 && (
                <div>
                    <h3>Recommended Songs:</h3>
                    <ul className="no-bullets">
                        {recommendedSongs.map((song, index) => (
                            <li key={index}>
                                <strong>{song.name}</strong> by {song.artist || "Unknown Artist"}
                                <br />
                                Album: {song.album} ({song.date})
                                <br />
                                Popularity: {song.popularity || "N/A"}
                            </li>
                        ))}
                    </ul>
                </div>
            )}
            {imageUrl && (
                <div>
                    <h3>Processed Image:</h3>
                    <img src={imageUrl} alt="Processed" style={{ maxWidth: '100%' }} />
                </div>
            )}
        </div>
    );
}

export default App;
