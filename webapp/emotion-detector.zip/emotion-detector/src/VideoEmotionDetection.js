import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import Papa from 'papaparse';
import './App.css';

function App() {
    const [predictions, setPredictions] = useState([]);
    const [processingTime, setProcessingTime] = useState(null);
    const [songs, setSongs] = useState([]);
    const [recommendedSongs, setRecommendedSongs] = useState([]);
    const [capturing, setCapturing] = useState(false);
    const [error, setError] = useState(null);
    const videoRef = useRef(null);
    const mediaRecorderRef = useRef(null);
    const chunks = useRef([]);

    useEffect(() => {
        Papa.parse('/songs1.csv', {
            download: true,
            header: true,
            complete: (result) => {
                setSongs(result.data);
            },
            error: (error) => {
                setError("Error loading song data");
            }
        });
    }, []);

    const handleStartCapture = async () => {
        setCapturing(true);
        setError(null);

        try {
            const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
            videoRef.current.srcObject = mediaStream;
            videoRef.current.play();

            mediaRecorderRef.current = new MediaRecorder(mediaStream);
            mediaRecorderRef.current.ondataavailable = (event) => chunks.current.push(event.data);
            mediaRecorderRef.current.onstop = handleStopCapture;
            
            mediaRecorderRef.current.start();
            setTimeout(() => mediaRecorderRef.current.stop(), 2000);

        } catch (err) {
            setError("Failed to access camera. Please allow camera permissions.");
            setCapturing(false);
        }
    };

    const handleStopCapture = async () => {
        const videoBlob = new Blob(chunks.current, { type: 'video/mp4' });
        chunks.current = [];
        const formData = new FormData();
        formData.append('video', videoBlob, 'captured_video.mp4');

        const mediaStream = videoRef.current.srcObject;
        const tracks = mediaStream.getTracks();
        tracks.forEach(track => track.stop());

        try {
            const response = await axios.post('http://127.0.0.1:8000/predict', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });

            const { processing_time, predictions } = response.data;
            setPredictions(predictions);
            setProcessingTime(processing_time);

            if (predictions.length > 0) {
                recommendSongs(predictions[0]);
            } else {
                setError("No mood detected from video.");
            }
        } catch (error) {
            setError("Failed to process video. Please try again.");
        } finally {
            setCapturing(false);
        }
    };

    const recommendSongs = (mood) => {
        const filteredSongs = songs.filter((song) => song.mood?.toLowerCase() === mood.toLowerCase());
        
        if (filteredSongs.length > 0) {
            const randomizedSongs = filteredSongs.sort(() => 0.5 - Math.random()).slice(0, 5);
            setRecommendedSongs(randomizedSongs);
        } else {
            setError(`No songs found for mood: ${mood}`);
        }
    };

    return (
        <div className="App">
            <h1>Emotion-Based Song Recommendation</h1>
            
            <div className="video-container">
                {capturing && (
                    <video ref={videoRef} className="video-preview" autoPlay muted></video>
                )}
            </div>
            
            <button onClick={handleStartCapture} disabled={capturing}>
                {capturing ? "Capturing..." : "Capture "}
            </button>

            {error && <div style={{ color: 'red' }}>{error}</div>}

            {processingTime && (
                <div>
                    <h3>Processing Time: {processingTime.toFixed(4)} seconds</h3>
                </div>
            )}
            {predictions.length > 0 && (
                <div>
                    <h3>Detected Mood: {predictions[0]}</h3>
                </div>
            )}
            {recommendedSongs.length > 0 && (
                <div>
                    <h3>Recommended Songs:</h3>
                    <ul style={{ listStyleType: 'none', padding: 0 }}>
                        {recommendedSongs.map((song, index) => (
                            <li key={index}>
                                <strong>{song.name}</strong> by {song.artist || 'Unknown Artist'} (Album: {song.album || 'Unknown Album'})
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
}

export default App;
